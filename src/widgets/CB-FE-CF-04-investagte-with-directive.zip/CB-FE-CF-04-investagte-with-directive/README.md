# CB-FE
Co-browsing front end development

# set up

Softwares:

apache tomact version 7
sublime text
node v6.11.0
